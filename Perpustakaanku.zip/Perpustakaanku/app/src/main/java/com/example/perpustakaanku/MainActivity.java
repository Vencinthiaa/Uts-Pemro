package com.example.perpustakaanku;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText username;
    private EditText password;
    private Button login;
    String getuser, getpass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        atribut();
        login();

    }

    public void atribut() {
        username = (EditText) findViewById(R.id.user);
        username.getText();
        password = (EditText) findViewById(R.id.pass);
        password.getText();
        login = (Button) findViewById(R.id.login);

        getuser = "mhs";
        getpass = "mhs";

    }

    public void login() {
        login.setOnClickListener( (v) -> {
            if (v == login) {
                if (username.getText().toString().equals(getuser) && password.getText().toString().equals(getpass)) {
                    username.setText("");
                    username.setText("");
                    Toast.makeText(getApplicationContext(), "Berhasil Login", Toast.LENGTH_LONG.show();

                    Intent i = new Intent(MainActivity.this, Buku.class);
                    starActivity(i);


                } else {
                    Toast.makeText(getApplicationContext(), "Username dan Password anda salah", Toast.LENGTH_LONG.show();
                    username.setText("");
                    password.setText("");
                    username.requestFocus();

                }
             }
        });
    }
}zz