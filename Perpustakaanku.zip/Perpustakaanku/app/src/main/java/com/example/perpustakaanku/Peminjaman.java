package com.example.perpustakaanku;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class Peminjaman extends AppCompatActivity {
    private int tambah2,tambah3,tambah4,tambah5,tambah6;
    private int jwb,jwb2,jwb3,jwb4,jwb5,jwb6;
    private TextView pesan2,pesan3,pesan4,pesan5,pesan6, jml;
    String get Pesan2, get Pesan3, get Pesan4, get Pesan5, get Pesan6;
    String get_JBiografi, get_JKamus,get_JIlmupengetahuan, get_JMajalah, get_JSuratKabar;

    @Override
    protected void onCreate (Bundle savedInstanceState) {
        super.onCreate(savedInstanceState;);
        setContentView(R.layout.activity_peminjaman);

        pesan2= (TextView) findViewById(R.id.pesan2)
        pesan3= (TextView) findViewById(R.id.pesan3)
        pesan4= (TextView) findViewById(R.id.pesan4)
        pesan5= (TextView) findViewById(R.id.pesan5)
        pesan6= (TextView) findViewById(R.id.pesan6)

        Bundle b = getIntent().getExtras();

        get_pesan2= b.getSring("p_Biografi");
        get_pesan3= b.getSring("p_Kamus");
        get_pesan4= b.getSring("p_Ilmupengetahuan");
        get_pesan5= b.getSring("p_Majalah");
        get_pesan6= b.getSring("p_Suratkabar");

        get_JBiografi = b.getString("jBiografi");
        get_JKamus = b.getString("jKamus");
        get_JIlmupengetahuan = b.getString("jIlmupengetahuan");
        get_JMajalah = b.getString("jMajalah");
        get_JSuratKabar = b.getString("jSuratKabar");

        pesan2.setText("- "+get_pesan2+" : "+get_JBiografi);
        pesan3.setText("- "+get_pesan3+" : "+get_JKamus);
        pesan4.setText("- "+get_pesan4+" : "+get_JIlmupengetahuan);
        pesan5.setText("- "+get_pesan5+" : "+get_JMajalah);
        pesan6.setText("- "+get_pesan6+" : "+get_JSuratKabar);

        Intent intent = getIntent();
        tambah2 = intent.getIntExtra("JB",0);
        tambah3 = intent.getIntExtra("JK",0);
        tambah4 = intent.getIntExtra("JI",0);
        tambah5 = intent.getIntExtra("JM",0);
        tambah6 = intent.getIntExtra("JS",0);


        jwb2 = tambah2 * 1;
        jwb3 = tambah3 * 1;
        jwb4 = tambah4 * 1;
        jwb5 = tambah5 * 1;
        jwb6 = tambah6 * 1;

        jwb = jwb2 + jwb3 + jwb4 + jwb5 + jwb6;
        jml.setText(jwb + "Buku");
    }


}

