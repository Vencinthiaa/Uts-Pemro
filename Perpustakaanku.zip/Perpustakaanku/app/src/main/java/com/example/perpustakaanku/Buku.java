package com.example.perpustakaanku;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

public class Buku extends AppCompatActivity {
    private CheckBox buku2,buku3, buku4,buku5, buku6;
    private EditText jm2, jm3, jm4, jm5, jm6;
    private Button pinjam;
    String biografi, kamus, ilmupengetahuan, majalah, suratkabar;
    String jml2, jml3, jml4, jml5, jml6;
    int j2, j3, j4, j5, j6;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buku);
        jumlah();
        tombol();
        checkbox();
        pinjam();
    }
    public void jumlah(){
    jm2= (EditText) findViewById(R.id.jml2);
    jm3= (EditText) findViewById(R.id.jml3);
    jm4= (EditText) findViewById(R.id.jml4);
    jm5= (EditText) findViewById(R.id.jml5);
    jm6= (EditText) findViewById(R.id.jml6);

    jm2.setEnabled(false);
    jm3.setEnabled(false);
    jm4.setEnabled(false);
    jm5.setEnabled(false);
    jm6.setEnabled(false);


    }
    public void tombol(){
        pinjam = (Button) findViewById(R.id.pinjam);

        buku2 = (CheckBox) findViewById(R.id.buku2);
        buku3 = (CheckBox) findViewById(R.id.buku3);
        buku4 = (CheckBox) findViewById(R.id.buku4);
        buku5 = (CheckBox) findViewById(R.id.buku5);
        buku6 = (CheckBox) findViewById(R.id.buku6);


    }
    public void checkbox
            buku2.setOnClickListener (view -> ) {
                if ((CheckBox)void).isChecked()){
                    jm2.setEnabled(true);
                    jm2.requestFocus();
        }else{
            jm2.setEnabled(false);
            jm2.setText("");
        }


    });
         buku3.setOnClickListener(view -> ) {
             if(((CheckBox)void).isChecked))){
            jm3.setEnabled(true);
            jm3.requestFocus();
        }else{
            jm3.setEnabled(false);
            jm3.setText("");
        }


    });
        buku4.setOnClickListener(view -> ) {
            if(((CheckBox)void).isChecked))){
            jm4.setEnabled(true);
            jm4.requestFocus()
    }else{
            jm4.setEnabled(false);
            jm4.setText("");
        }


    });
        buku5.setOnClickListener(view -> ) {
            if(((CheckBox)void).isChecked))){
            jm5.setEnabled(true);
            jm5.requestFocus()
        }else{
            jm5.setEnabled(false);
            jm5.setText("");
        }


    });
        buku6.setOnClickListener(view -> ) {
            if(((CheckBox)void).ischecked))){
            jm6.setEnabled(true);
            jm6.requestFocus()
        }else{
            jm6.setEnabled(false);
            jm6.setText("");
        }


    });

}
    public void pinjam(){
        pinjam.setOnClickListener(view -> ) {
            if (View == pinjam) {
                Toast.makeText(getApplicationContext()
                this, "Terimakasih Sudah Meminjam", Toast.LENGTH_SHORT).show();
            } if (buku2.isChecked()) {
                biografi = buku2.getText().toString();
                jml2 = jm2.getText().toString();
                j2 = Integer.parseInt(jml2);
            }
            if (buku3.isChecked()) {
                kamus = buku3.getText().toString();
                jml3 = jm3.getText().toString();
                j3 = Integer.parseInt(jml3);
            }
            if (buku4.isChecked()) {
                ilmupengetahuan = buku4.getText().toString();
                jml4 = jm4.getText().toString();
                j4 = Integer.parseInt(jml4);
            }
            if (buku5.isChecked()) {
                majalah = buku5.getText().toString();
                jml5 = jm5.getText().toString();
                j5 = Integer.parseInt(jml5);
            }
            if (buku6.isChecked()) {
                suratkabar = buku6.getText().toString();
                jml6 = jm6.getText().toString();
                j6 = Integer.parseInt(jml6);
            }
            Intent intent = new Intent(Buku.this, Peminjaman.class);
            Bundle b = new Bundle();

            b.putString("p_Biografi", biografi);
            b.putString("p_Kamus", kamus);
            b.putString("p_Ilmupengetahuan", ilmupengetahuan);
            b.putString("p_Majalah", majalah);
            b.putString("p_Suratkabar", suratkabar);
            b.putString("jBiografi", jml2);
            b.putString("jKamus", jml3);
            b.putString("jIlmupengetahuan", jml4);
            b.putString("jMajalah", jml5);
            b.putString("jSuratkabar", jml6);
            intent.putExtra("JB", j2);
            intent.putExtra("Jk", j3);
            intent.putExtra("JI", j4);
            intent.putExtra("JM", j5);
            intent.putExtra("JS", j6);
            intent.putExtra(b);
            startActivity(intent);

        });

    }

}